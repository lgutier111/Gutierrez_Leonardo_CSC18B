package com.GutierrezLeonardo.CIS18B.Assignment3_032515;

import javax.swing.JFrame;

public class TestPieChart 
{
   // execute application
   public static void main(String[] args)
   {
      // create frame for ArcsJPanel
      JFrame frame = new JFrame("Pie Chart");
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

      PieChartPanel pieChart = new PieChartPanel();
      frame.add(pieChart); 
      frame.setSize(400, 400);
      frame.setLocation(500, 300);
      frame.setResizable(false);
      frame.setVisible(true);
   } 
} // end class DrawArcs
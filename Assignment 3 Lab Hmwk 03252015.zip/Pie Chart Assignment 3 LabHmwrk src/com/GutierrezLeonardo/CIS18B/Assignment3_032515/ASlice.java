package com.GutierrezLeonardo.CIS18B.Assignment3_032515;

import java.awt.Color;

public class ASlice extends PieChartPanel{
	
	protected float value;
	protected Color color;
	
	public ASlice(float value, Color color){
		
		this.value = value;
		this.color = color;
	}

}

package com.GutierrezLeonardo.CIS18B.Assignment3_032515;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JPanel;

public class PieChartPanel extends JPanel{
	
	@Override
	   public void paintComponent(Graphics g)
	   {
	      super.paintComponent(g);  
	     
	      // hard code the area where I want my pie chart always to be
	      int myAreaX = 60;
	      int myAreaY = 50;
	      int myWidth = 270;
	      int myHeight = 270;
	     
	      // declare my arrya of pie slices
	      ASlice[] slices = { new ASlice(5, Color.RED),
	    		             new ASlice(33, Color.GREEN),
	    		             new ASlice(20, Color.YELLOW),
	    		             new ASlice(15, Color.BLACK)};
	
	     // Get the total the slice values in the array ASlice
	     float total = 0;
	     for (int i = 0; i < slices.length; i++){
	    	 total += slices[i].value;
	     }
	      
	     // Loop through the values to create the pie chart
	     float curValue = 0;
	     int startAngle = 0;
	     for (int i = 0; i < slices.length; i++){
	    	 startAngle = (int) (curValue * 360 / total);
	    	 System.out.println("The start angle is: " + startAngle);
	    	 int arcAngle = (int) (slices[i].value * 360 / total);
	    	 System.out.println("The arc angle is: " + arcAngle);
	    	 g.setColor(slices[i].color);
	    	 g.fillArc(myAreaX,  myAreaY,  myWidth,  myHeight,  startAngle,  arcAngle);
	    	 curValue += slices[i].value;
	    	 System.out.println("the curValue is: " + curValue);
	     }
	     
	     
	     /*
	      // start at 0 and sweep 360 degrees
	      //       (  x,   y, width, height, startAngle, arcAngle)
	     
	      g.setColor(Color.RED);
	      g.fillArc(60, 50, 270, 270, 0, 24);
	      
	      g.setColor(Color.GREEN);
	      g.fillArc(60, 50, 270, 270, 24, 162);
	      
	      g.setColor(Color.YELLOW);
	      g.fillArc(60, 50, 270, 270, 187, 98);

	      g.setColor(Color.BLACK);
	      g.fillArc(60, 50, 270, 270, 286, 73);

	     */
	     
	   } 
	
}
